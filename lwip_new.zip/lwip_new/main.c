#include "lwip/init.h"
#include "lwip/netif.h"
#include "netif/ethernet.h"
#include <string.h>
#include <stdio.h>
struct netif net_test;
unsigned int LocalTime =0;//全局定时器
unsigned int TCPTime=0;
unsigned int ARPTime=0;

#define  OS_TICKS_PER_SEC 1000 //一秒时钟计数器增加的值

#define TCPTime_INTERVAL OS_TICKS_PER_SEC/4 //250ms
#define ARPTime_INTERVAL OS_TICKS_PER_SEC*5 //5s

void os_time_hook(void)
{
	LocalTime++;
}

void get_packet(void)
{



}
void lwip_init_task(void)
{
	ip4_addr_t addr;
	ip4_addr_t netmask;
	ip4_addr_t gw;
	size_t len;

	lwip_init();

	IP4_ADDR(&addr, 172, 30, 115, 84);
	IP4_ADDR(&netmask, 255, 255, 255, 0);
	IP4_ADDR(&gw, 172, 30, 115, 1);

	netif_add(&net_test, &addr, &netmask, &gw, &net_test, NULL, ethernet_input);
	netif_set_default(&net_test);
	netif_set_up(&net_test);
}
int main(int argc, char** argv)
{
	lwip_init_task();
	while(1)
	{
		get_packet();
		sleep(4);
		if(LocalTime-TCPTime>=TCPTime_INTERVAL)
		{
			TCPTime=LocalTime;
			tcp_tmr();
		}
		if(LocalTime-ARPTime>=ARPTime_INTERVAL)
		{
			ARPTime=LocalTime;
			etharp_tmr();
		}
	}
    return 0;
}